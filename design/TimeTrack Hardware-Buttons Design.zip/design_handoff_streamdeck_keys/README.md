# Handoff: Stream-Deck Tastenflächen ("Glass Keys") — TimeTrack #133

## Overview

Neugestaltung der Tastenflächen des TimeTrack Stream-Deck-Plugins. Jede Taste
schaltet einen Timer für (Kunde, Projekt|null); das Tastenbild zeigt den
Live-Zustand. Bisher waren die Flächen flache Tailwind-Graublautöne mit roher
Kundenfarbe und ohne Zeitanzeige. Neu:

1. **Glass-Look der App auf der Taste** — dunkles Glas (\`#242844\` → \`#0d1020\`),
   Lichtkante oben, 1-px-Innenkante, Kundenfarbe als weicher Wash von unten.
2. **Laufzeit auf der Taste** — \`h:mm\` in Monospace, groß und mittig.
3. **Minutenring** — der weiße Rahmen füllt sich einmal pro Minute; reine
   SVG-Animation, kein zusätzlicher Poll-Traffic, beim Rendern sekundengenau
   zur Uhr synchronisiert.
4. **Kundenfarbe normalisiert** — jede DB-Farbe wird in OKLab auf L = 0.65 /
   C = 0.15 gezogen. Weiße Schrift hat damit immer ≥ 4.5:1, auch bei
   Pastellgelb oder Neonpink.

## About the Design Files

Die Datei \`Stream Deck Tastenflaechen.dc.html\` in diesem Bundle ist eine
**Design-Referenz in HTML** — ein Prototyp, der Aussehen und Verhalten zeigt,
kein Produktionscode zum Kopieren. Die eigentliche Implementierung gehört in
das bestehende Plugin-Projekt (\`streamdeck-plugin/\`, TypeScript, Elgato SDK v2)
und folgt dessen Mustern.

Ausnahme: \`keyImage.ts\` in diesem Bundle **ist** produktionsnaher Code — eine
Drop-in-Ablösung für \`svgImage()\` aus \`src/actions/toggle-timer.ts\`. Sie ist
abhängigkeitsfrei und typisiert; Formatierung/Lint bitte an das Repo angleichen
(das Plugin hat eine eigene \`tsconfig.json\` und ist in \`.prettierignore\`
sowie \`eslint.config.mjs\` bewusst ausgeklammert).

## Fidelity

**High-fidelity.** Alle Farben, Größen, Positionen und Schriftgrößen sind final
und unten in Tastenkoordinaten (viewBox \`0 0 144 144\`) angegeben. Die
Tastenfläche 1:1 so umsetzen.

## Screens / Views

Es gibt genau eine "View": die 144×144-Tastenfläche in vier Zuständen. Alle
teilen dieselbe Hülle:

- Hülle: \`<rect x="4" y="4" width="136" height="136" rx="22">\` — der 4-px-Rand
  bleibt frei, damit die Stream-Deck-Tastenkappe nicht in die Fläche schneidet.
- Innenkante ("Glas"): \`<rect x="5.5" y="5.5" width="133" height="133" rx="20.5">\`,
  \`stroke="#ffffff"\`, \`stroke-opacity="0.14"\` (offline: 0.07).
- Lichtkante oben: \`<rect x="10" y="10" width="124" height="58" rx="17">\` mit
  vertikalem Weiß-Gradient 0.13 → 0 (running: Höhe 56, 0.22 → 0).
- Alle Texte \`text-anchor="middle"\`, x = 72.

### 1 · running

| Element | Wert |
| --- | --- |
| Fläche | Linearer Gradient \`x1=0 y1=0 x2=0.35 y2=1\`: 0 % = Kundenfarbe · L×1.18, 55 % = normalisierte Kundenfarbe, 100 % = L×0.62 |
| Minutenring (Spur) | \`rect x=9 y=9 w=126 h=126 rx=19\`, stroke \`#ffffff\` @ 0.22, \`stroke-width=3\` |
| Minutenring (Fortschritt) | gleiche Geometrie, stroke \`#ffffff\` deckend, \`stroke-linecap="round"\`, \`pathLength="100"\`, \`transform="rotate(-90 72 72)"\`, \`<animate attributeName="stroke-dasharray" values="0 100;100 100" dur="60s" begin="-{sec % 60}s" repeatCount="indefinite">\` |
| Kopfzeile (Kunde) | y 32, 13 px, weight 500, \`#ffffff\` @ 0.8 |
| Projektzeile | y 58, 19 px, weight 600, \`#ffffff\` — nur wenn ein Projekt gesetzt ist (sonst steht der Kunde in der Kopfzeile) |
| Laufzeit | y 104, 34 px, weight 700, Monospace, \`#ffffff\`, \`letter-spacing="-1"\`, Format \`h:mm\` |
| Puls-Punkt | \`circle cx=72 cy=124 r=4.5\` \`#ffffff\`, Opacity 1 → 0.35 → 1 über 2 s, endlos |

### 2 · idle

| Element | Wert |
| --- | --- |
| Fläche | Vertikaler Gradient \`#242844\` → \`#0d1020\` |
| Kundenfarb-Wash | \`radialGradient cx=0.5 cy=1 r=0.85\`, normalisierte Kundenfarbe @ 0.32 → 0, über die ganze Hülle |
| Kopfzeile (Kunde) | y 34, 14 px, weight 500, \`#8b93bc\` |
| Hauptzeilen | 21 px, weight 600, \`#e8eaf6\`; 1 Zeile → y 84 · 2 Zeilen → y 76/101 · 3 Zeilen → y 68/93/118 |
| Kundenfarb-Balken | \`rect x=52 y=122 w=40 h=5 rx=2.5\`, normalisierte Kundenfarbe |

> Der Balken war vorher 112 px breit und dominierte die Fläche. 40 px zentriert
> lesen sich als Zustandsmarke, nicht als Grafik. Falls er breiter gewünscht ist:
> \`x\` und \`width\` symmetrisch anpassen (x = (144 − width) / 2).

### 3 · unset (keine Taste konfiguriert)

| Element | Wert |
| --- | --- |
| Fläche | Vertikaler Gradient \`#1c2036\` → \`#0d1020\` |
| Rahmen | \`rect x=9 y=9 w=126 h=126 rx=19\`, stroke \`#ffffff\` @ 0.20, \`stroke-width=2\`, \`stroke-dasharray="7 7"\` |
| Uhr-Glyph | \`circle cx=72 cy=52 r=17\` + Zeiger \`72,43→72,53\` und \`72,53→79,57\`, stroke \`#5b4ef0\`, \`stroke-width=2.5\`, runde Enden — Geometrie aus \`imgs/plugin.svg\`, skaliert |
| Text | y 96 und y 118, 18 px, weight 600, \`#8b93bc\`: "Kunde" / "wählen" (EN: "Pick a" / "client") |

### 4 · offline (TimeTrack nicht erreichbar)

| Element | Wert |
| --- | --- |
| Fläche | Vertikaler Gradient \`#20222c\` → \`#0f1116\` (entsättigt, keine Kundenfarbe) |
| Innenkante | \`#ffffff\` @ 0.07 |
| Kopfzeile | y 34, 14 px, \`#5b6070\` |
| Hauptzeilen | wie idle, aber \`#767c8e\` |
| Offline-Chip | \`rect x=38 y=112 w=68 h=22 rx=11\`, fill none, stroke \`#4a5270\` \`stroke-width=1.5\`; Text y 127, 13 px, weight 500, \`#767c8e\`, "offline" |

## Interactions & Behavior

- **Tastendruck** → \`toggleTimer(clientId, projectId)\` über die Bridge; danach
  \`showOk()\`/\`showAlert()\` wie bisher und ein \`refreshAll()\`. Kein eigener
  "gedrückt"-Zustand — den Overlay zeichnet das Stream Deck selbst.
- **Zustandswechsel** wird nicht animiert (das SDK tauscht das Bild hart aus).
- **Minutenring**: läuft im SVG selbst weiter, \`POLL_MS\` bleibt bei 2000. Beim
  Rendern setzt \`begin="-{sec % 60}s"\` den Ring auf die aktuelle Sekunde, damit
  er nach Neustart/Seitenwechsel synchron ist.
- **Puls-Punkt**: 2 s, endlos, ebenfalls im SVG.
- **Rendern nur bei Änderung**: das Bild ändert sich sichtbar nur jede Minute.
  Empfehlung, um Bildübertragungen zu sparen: pro Taste den letzten
  \`(state, minute, clientId, projectId)\`-Schlüssel merken und \`setImage()\` nur
  bei Änderung aufrufen. Nach \`onWillAppear\` einmal erzwingen.
- **Lange Namen**: \`keyLabel()\` bleibt unverändert (Umbruch bei 11 Zeichen,
  Kürzung mit "…"). Im Running-Zustand wird nur \`lines[0]\` gezeigt — der Platz
  gehört der Zeit.

## State Management

Kein neuer Store. Was gebraucht wird:

- \`getTimerStatus()\` liefert bereits \`started_at\` — die Laufzeit wird lokal
  gerechnet: \`elapsedSec = (Date.now() - started_at) / 1000\`. **Kein
  Protokollwechsel an der Bridge nötig.**
- Zustandsableitung wie heute in \`render()\`:
  \`clientId == null → 'unset'\` · \`status === 'unavailable' → 'offline'\` ·
  Ziel-Match → \`'running'\` · sonst \`'idle'\`.
- Optional der oben beschriebene \`lastKey\`-Cache pro Tastenkontext.

### Aufrufstelle (ersetzt den Body von \`ToggleTimer.render()\`)

\`\`\`ts
if (typeof settings.clientId !== 'number') {
  await key.setImage(keyImage({ state: 'unset', label: { header: '', lines: [] } }))
  return
}
const label = keyLabel(settings)
if (status === 'unavailable') {
  await key.setImage(keyImage({ state: 'offline', label }))
  return
}
const active =
  status !== null &&
  status.client_id === settings.clientId &&
  (status.project_id ?? null) === (settings.projectId ?? null)
await key.setImage(
  active
    ? keyImage({
        state: 'running',
        label,
        color: settings.color,
        elapsedSec: (Date.now() - status.started_at) / 1000
      })
    : keyImage({ state: 'idle', label, color: settings.color })
)
\`\`\`

## Design Tokens

**Herkunft:** Glas- und Textfarben stammen aus \`src/renderer/src/assets/base.css\`
(\`.dark\`-Block des Glass-Themes), der Akzent \`#5b4ef0\` aus dem \`:root\`-Block
und \`imgs/plugin.svg\`.

| Token | Wert | Verwendung |
| --- | --- | --- |
| Glas oben | \`#242844\` | idle Gradient-Start |
| Glas unten | \`#0d1020\` | idle/unset Gradient-Ende (= \`--page-bg\` dark) |
| Glas unset oben | \`#1c2036\` | unset Gradient-Start |
| Grau oben / unten | \`#20222c\` / \`#0f1116\` | offline |
| Text primär | \`#e8eaf6\` | \`--text\` (dark) |
| Text sekundär | \`#8b93bc\` | \`--text2\` (dark) — Kopfzeile, unset |
| Text tertiär | \`#4a5270\` | \`--text3\` (dark) — Chip-Rahmen |
| Text offline | \`#767c8e\` / \`#5b6070\` | Hauptzeilen / Kopfzeile |
| Akzent | \`#5b4ef0\` | Uhr-Glyph im unset-Zustand |
| Akzent-Fallback | \`#8b7cf8\` | \`--accent\` (dark), bei fehlender Kundenfarbe |
| Kundenfarbe normalisiert | OKLab L 0.65 / C 0.15 | Wash, Balken, Running-Gradient |
| Radien | 22 (Hülle) · 20.5 (Innenkante) · 19 (Ring) · 17 (Lichtkante) · 11 (Chip) · 2.5 (Balken) | |
| Schrift | \`Segoe UI, Helvetica, Arial, sans-serif\` | alle Labels |
| Monospace | \`Consolas, Menlo, monospace\` | Laufzeit (springt sonst pro Ziffer) |
| Schriftgrößen | 34 (Zeit) · 21 (Hauptzeile) · 19 (Projekt running) · 18 (unset) · 14/13 (Kopfzeile, Chip) | |

**Wichtig:** Inter ist im Key-SVG nicht verfügbar (kein Font-Embedding im
Stream-Deck-Renderer). Deshalb bleibt es bei Systemschriften — nicht auf Inter
umstellen, das fällt sonst auf einen Default zurück.

## Assets

Keine neuen Dateien. Der Uhr-Glyph im unset-Zustand ist die Geometrie aus
\`streamdeck-plugin/com.timetrack.streamdeck.sdPlugin/imgs/plugin.svg\`, inline
nachgezeichnet und skaliert. \`imgs/toggle.svg\` (Action-Icon in der
Stream-Deck-Bibliothek) bleibt unverändert — optional später an den Glass-Look
angleichen, ist aber nicht Teil dieses Handoffs.

## Files

| Datei | Rolle |
| --- | --- |
| \`keyImage.ts\` | Drop-in-Ersatz für \`svgImage()\` — alle vier Zustände, Farbnormalisierung, Zeitformat |
| \`Stream Deck Tastenflaechen.dc.html\` | Design-Referenz: Ist-Zustand vs. neu, alle Zustände, 6er-Raster auf hellem und dunklem Schreibtisch |
| \`support.js\` | Runtime für die HTML-Referenz (nur zum Öffnen im Browser nötig) |

### Betroffene Dateien im Zielrepo (\`skoedr/time-tracking\`, branch \`main\`)

- \`streamdeck-plugin/src/actions/toggle-timer.ts\` — \`svgImage()\` ersetzen,
  \`render()\` anpassen (siehe oben). \`keyLabel()\`, \`wrap()\`, \`escapeXml()\` bleiben.
- \`streamdeck-plugin/src/bridge.ts\` — nur lesen: \`RunningTimer.started_at\`
  bestätigen, kein Änderungsbedarf erwartet.
- \`streamdeck-plugin/com.timetrack.streamdeck.sdPlugin/manifest.json\` —
  \`UserTitleEnabled: false\` bleibt zwingend: ein Nutzer-Titel würde über der
  Fläche liegen.

### Offene Punkte für die Umsetzung

1. Der \`unset\`-Text ist hart deutsch. Das Plugin hat bisher kein i18n
   ("Set up in the inspector" war englisch) — entweder englisch belassen oder die
   Locale-Dateien der App anzapfen. **Entscheidung liegt beim Team.**
2. Bildübertragung: den \`lastKey\`-Cache einbauen oder erst messen, ob
   \`setImage()\` alle 2 s stört. Auf einem physischen Deck ungetestet.
3. Kontrast wurde gegen hellen und dunklen Hintergrund geprüft (siehe HTML,
   Abschnitt "Sechs Tasten"), aber nur am Bildschirm — auf echter Hardware
   gegenprüfen.
